import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Song, Playlist, PlayerState, ViewState, QueueState } from './types';
import { Sidebar } from './components/Sidebar';
import { Player } from './components/Player';
import { SongList } from './components/SongList';
import { Button } from './components/Button';
import { EditSongModal } from './components/EditSongModal';
import { Plus, Music, Trash, ArrowLeft, ListMusic } from 'lucide-react';
import { get, set } from 'idb-keyval';

// --- Constants & Helpers ---

const generateId = () => Math.random().toString(36).substr(2, 9);

// --- Main Component ---

function App() {
  // --- State ---
  const [songs, setSongs] = useState<Song[]>([]);
  const [playlists, setPlaylists] = useState<Playlist[]>([]);
  const [view, setView] = useState<ViewState>('library');
  const [activePlaylistId, setActivePlaylistId] = useState<string | null>(null);
  const [editingSong, setEditingSong] = useState<Song | null>(null);
  const [isLoaded, setIsLoaded] = useState(false);
  
  const [playerState, setPlayerState] = useState<PlayerState>({
    currentSongId: null,
    isPlaying: false,
    volume: 1,
    progress: 0,
    isShuffle: false,
    repeatMode: 'off',
  });

  // Keep track of the play queue
  const [queue, setQueue] = useState<QueueState>({
    originalQueue: [],
    shuffledQueue: [],
    currentIndex: -1
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  // --- Persistence Logic ---

  useEffect(() => {
    // Load data from IndexedDB on mount
    const loadData = async () => {
        try {
            const [savedSongs, savedPlaylists] = await Promise.all([
                get<Song[]>('songs'),
                get<Playlist[]>('playlists')
            ]);

            if (savedSongs) {
                // We need to recreate the blob URLs from the saved File objects
                const rehydratedSongs = savedSongs.map(s => ({
                    ...s,
                    url: URL.createObjectURL(s.file)
                }));
                setSongs(rehydratedSongs);
            }
            if (savedPlaylists) {
                setPlaylists(savedPlaylists);
            }
        } catch (err) {
            console.error("Failed to load saved data:", err);
        } finally {
            setIsLoaded(true);
        }
    };
    loadData();
  }, []);

  useEffect(() => {
    // Save data to IndexedDB whenever it changes
    // Only save if initial load is complete to avoid overwriting with empty states
    if (isLoaded) {
        set('songs', songs).catch(err => console.error("Failed to save songs:", err));
        set('playlists', playlists).catch(err => console.error("Failed to save playlists:", err));
    }
  }, [songs, playlists, isLoaded]);

  // --- Derived State ---

  const currentSong = useMemo(() => 
    songs.find(s => s.id === playerState.currentSongId) || null
  , [songs, playerState.currentSongId]);

  const displayedSongs = useMemo(() => {
    if (view === 'library') return songs;
    if (view === 'playlist' && activePlaylistId) {
      const pl = playlists.find(p => p.id === activePlaylistId);
      if (!pl) return [];
      // Preserve order in playlist
      return pl.songIds.map(id => songs.find(s => s.id === id)).filter(Boolean) as Song[];
    }
    return [];
  }, [view, activePlaylistId, songs, playlists]);

  const activePlaylist = useMemo(() => 
    playlists.find(p => p.id === activePlaylistId)
  , [playlists, activePlaylistId]);

  // --- Handlers ---

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    const newSongs: Song[] = Array.from(files).map((file: File) => ({
      id: generateId(),
      title: file.name.replace(/\.[^/.]+$/, ""), // Simple title extraction
      artist: 'Unknown Artist', // Parsing ID3 tags requires heavy lib, skipping for simple app
      duration: 0, // Will be updated when loaded in audio element
      file: file,
      url: URL.createObjectURL(file),
      dateAdded: Date.now(),
    }));

    setSongs(prev => [...prev, ...newSongs]);
    // Reset input
    if (fileInputRef.current) fileInputRef.current.value = '';
    
    // Automatically switch to library if uploading
    if (view !== 'library') {
        setView('library');
        setActivePlaylistId(null);
    }
  };

  const createPlaylist = () => {
    const name = prompt("Enter playlist name:");
    if (!name) return;
    const newPlaylist: Playlist = {
      id: generateId(),
      name,
      songIds: [],
      createdAt: Date.now(),
    };
    setPlaylists(prev => [...prev, newPlaylist]);
    // Switch to new playlist
    setView('playlist');
    setActivePlaylistId(newPlaylist.id);
  };

  const deletePlaylist = (id: string) => {
      if(confirm("Are you sure you want to delete this playlist?")) {
        setPlaylists(prev => prev.filter(p => p.id !== id));
        if (activePlaylistId === id) {
            setView('library');
            setActivePlaylistId(null);
        }
      }
  }

  const addToPlaylist = (songId: string, playlistId: string) => {
    setPlaylists(prev => prev.map(pl => {
      if (pl.id === playlistId && !pl.songIds.includes(songId)) {
        return { ...pl, songIds: [...pl.songIds, songId] };
      }
      return pl;
    }));
  };

  const removeFromPlaylist = (songId: string, playlistId: string) => {
       setPlaylists(prev => prev.map(pl => {
          if (pl.id === playlistId) {
              return { ...pl, songIds: pl.songIds.filter(id => id !== songId)};
          }
          return pl;
       }));
  };

  const deleteSong = (songId: string) => {
      // Stop playing if deleted
      if (playerState.currentSongId === songId) {
          setPlayerState(prev => ({...prev, isPlaying: false, currentSongId: null}));
      }
      // Remove from library
      setSongs(prev => prev.filter(s => s.id !== songId));
      // Remove from all playlists
      setPlaylists(prev => prev.map(pl => ({
          ...pl,
          songIds: pl.songIds.filter(id => id !== songId)
      })));
  };

  const saveSongDetails = (id: string, title: string, artist: string) => {
    setSongs(prev => prev.map(s => s.id === id ? { ...s, title, artist } : s));
    setEditingSong(null);
  };

  // --- Player Logic ---

  const playSong = (songId: string) => {
    // Determine the context (Are we playing from Library or a Playlist?)
    // We rebuild the queue based on displayedSongs
    const songIds = displayedSongs.map(s => s.id);
    const index = songIds.indexOf(songId);

    // Shuffle logic
    let shuffledIds = [...songIds];
    if (playerState.isShuffle) {
        // Simple shuffle that keeps started song first
        const rest = shuffledIds.filter(id => id !== songId);
        for (let i = rest.length - 1; i > 0; i--) {
            const j = Math.floor(Math.random() * (i + 1));
            [rest[i], rest[j]] = [rest[j], rest[i]];
        }
        shuffledIds = [songId, ...rest];
    }

    setQueue({
        originalQueue: songIds,
        shuffledQueue: shuffledIds,
        currentIndex: playerState.isShuffle ? 0 : index
    });

    setPlayerState(prev => ({ 
        ...prev, 
        currentSongId: songId, 
        isPlaying: true,
        progress: 0 
    }));
  };

  const togglePlay = () => {
    setPlayerState(prev => ({ ...prev, isPlaying: !prev.isPlaying }));
  };

  const nextSong = () => {
     if (queue.originalQueue.length === 0) return;

     const activeQueue = playerState.isShuffle ? queue.shuffledQueue : queue.originalQueue;
     let nextIndex = queue.currentIndex + 1;
     
     if (nextIndex >= activeQueue.length) {
         if (playerState.repeatMode === 'all') {
             nextIndex = 0;
         } else {
             // End of queue
             setPlayerState(prev => ({ ...prev, isPlaying: false }));
             return;
         }
     }
     
     setQueue(prev => ({ ...prev, currentIndex: nextIndex }));
     setPlayerState(prev => ({ ...prev, currentSongId: activeQueue[nextIndex], isPlaying: true, progress: 0 }));
  };

  const prevSong = () => {
      // If played more than 3 seconds, restart song
      if (playerState.progress > 3) {
           if(document.querySelector('audio')) {
               const audio = document.querySelector('audio') as HTMLAudioElement;
               audio.currentTime = 0;
           }
           setPlayerState(prev => ({...prev, progress: 0}));
           return;
      }

      const activeQueue = playerState.isShuffle ? queue.shuffledQueue : queue.originalQueue;
      let prevIndex = queue.currentIndex - 1;

      if (prevIndex < 0) {
           if (playerState.repeatMode === 'all') {
               prevIndex = activeQueue.length - 1;
           } else {
               prevIndex = 0; // Stay at start
           }
      }

      setQueue(prev => ({ ...prev, currentIndex: prevIndex }));
      setPlayerState(prev => ({ ...prev, currentSongId: activeQueue[prevIndex], isPlaying: true, progress: 0 }));
  };

  const onSongEnded = () => {
      if (playerState.repeatMode === 'one') {
          // Handled by loop attribute in Player component, but we reset progress here technically
          // Actually loop attr handles it, but let's sync state
           setPlayerState(prev => ({...prev, progress: 0}));
      } else {
          nextSong();
      }
  };

  return (
    <div className="flex h-screen bg-background text-textMain font-sans">
      {/* Hidden File Input */}
      <input 
        type="file" 
        ref={fileInputRef}
        onChange={handleFileUpload}
        accept="audio/*"
        multiple
        className="hidden"
      />

      <Sidebar 
        currentView={view}
        selectedPlaylistId={activePlaylistId}
        playlists={playlists}
        onChangeView={(v, id) => {
            setView(v);
            if (id) setActivePlaylistId(id);
            else setActivePlaylistId(null);
        }}
        onCreatePlaylist={createPlaylist}
        onUploadClick={() => fileInputRef.current?.click()}
      />

      <main className="flex-1 flex flex-col relative overflow-hidden pb-24">
        {/* Header Area */}
        <div className="h-16 px-8 flex items-center justify-between bg-background/50 backdrop-blur-sm sticky top-0 z-20">
            {view === 'library' && (
                <div className="flex items-center space-x-4">
                    <h1 className="text-2xl font-bold text-white">Library</h1>
                    <span className="text-textMuted text-sm">{songs.length} songs</span>
                </div>
            )}
            
            {view === 'playlist' && activePlaylist && (
                <div className="flex items-center justify-between w-full">
                     <div className="flex items-center space-x-4">
                        <div className="h-12 w-12 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-md flex items-center justify-center shadow-lg">
                            <ListMusic className="text-white w-6 h-6" />
                        </div>
                        <div>
                            <h1 className="text-2xl font-bold text-white">{activePlaylist.name}</h1>
                            <span className="text-textMuted text-sm">{activePlaylist.songIds.length} songs</span>
                        </div>
                     </div>
                     <div className="flex items-center space-x-2">
                        <Button variant="danger" size="sm" onClick={() => deletePlaylist(activePlaylist.id)}>
                            <Trash className="w-4 h-4 mr-2" />
                            Delete Playlist
                        </Button>
                     </div>
                </div>
            )}
            
            <div className="flex items-center space-x-4">
                 <Button onClick={() => fileInputRef.current?.click()}>
                    <Plus className="w-4 h-4 mr-2" />
                    Add Songs
                 </Button>
            </div>
        </div>

        {/* Content Area */}
        <div className="flex-1 overflow-y-auto custom-scrollbar">
            <div className="px-4 md:px-8 py-4">
                <SongList 
                    songs={displayedSongs}
                    currentSongId={playerState.currentSongId}
                    isPlaying={playerState.isPlaying}
                    playlists={playlists}
                    onPlay={playSong}
                    onPause={togglePlay}
                    onDelete={view === 'library' ? deleteSong : (id) => activePlaylistId && removeFromPlaylist(id, activePlaylistId)}
                    onAddToPlaylist={addToPlaylist}
                    onEdit={setEditingSong}
                />
            </div>
        </div>
      </main>

      <Player 
        currentSong={currentSong}
        playerState={playerState}
        togglePlay={togglePlay}
        nextSong={nextSong}
        prevSong={prevSong}
        toggleShuffle={() => setPlayerState(p => ({...p, isShuffle: !p.isShuffle}))}
        toggleRepeat={() => setPlayerState(p => ({
            ...p, 
            repeatMode: p.repeatMode === 'off' ? 'all' : p.repeatMode === 'all' ? 'one' : 'off'
        }))}
        onTimeUpdate={(t) => setPlayerState(p => ({...p, progress: t}))}
        onDurationChange={(d) => {
            if (currentSong && currentSong.duration === 0) {
                 // Update duration in library if we just learned it
                 setSongs(prev => prev.map(s => s.id === currentSong.id ? {...s, duration: d} : s));
            }
        }}
        onEnded={onSongEnded}
        setVolume={(v) => setPlayerState(p => ({...p, volume: v}))}
      />

      <EditSongModal 
        isOpen={!!editingSong}
        song={editingSong}
        onClose={() => setEditingSong(null)}
        onSave={saveSongDetails}
      />
    </div>
  );
}

export default App;