import React from 'react';
import { Play, Pause, Music, Trash2, Plus, ListMusic, Pencil } from 'lucide-react';
import { Song, Playlist } from '../types';
import { Button } from './Button';

interface SongListProps {
  songs: Song[];
  currentSongId: string | null;
  isPlaying: boolean;
  playlists: Playlist[];
  onPlay: (songId: string) => void;
  onPause: () => void;
  onDelete?: (songId: string) => void;
  onAddToPlaylist?: (songId: string, playlistId: string) => void;
  onEdit?: (song: Song) => void;
}

export const SongList: React.FC<SongListProps> = ({
  songs,
  currentSongId,
  isPlaying,
  playlists,
  onPlay,
  onPause,
  onDelete,
  onAddToPlaylist,
  onEdit
}) => {
  const [activeMenuId, setActiveMenuId] = React.useState<string | null>(null);

  const formatTime = (seconds: number) => {
    if (!seconds && seconds !== 0) return '--:--';
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const handlePlaylistClick = (e: React.MouseEvent, songId: string) => {
    e.stopPropagation();
    setActiveMenuId(activeMenuId === songId ? null : songId);
  };

  // Close menu when clicking outside
  React.useEffect(() => {
    const handleClickOutside = () => setActiveMenuId(null);
    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  if (songs.length === 0) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-textMuted space-y-4">
        <Music className="w-16 h-16 opacity-20" />
        <p className="text-lg">No songs found.</p>
        <p className="text-sm">Upload music to get started.</p>
      </div>
    );
  }

  return (
    <div className="w-full">
      <div className="grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 px-4 py-3 text-xs font-medium text-textMuted uppercase tracking-wider border-b border-surfaceHighlight sticky top-0 bg-background/95 backdrop-blur-sm z-10">
        <div className="w-8 text-center">#</div>
        <div>Title</div>
        <div className="hidden md:block">Date Added</div>
        <div className="text-right pr-4">Duration</div>
        <div className="w-8"></div>
      </div>
      
      <div className="flex flex-col pb-4">
        {songs.map((song, index) => {
          const isCurrent = song.id === currentSongId;
          const isCurrentPlaying = isCurrent && isPlaying;

          return (
            <div
              key={song.id}
              className={`group grid grid-cols-[auto_1fr_1fr_auto_auto] gap-4 px-4 py-3 items-center hover:bg-surfaceHighlight/50 rounded-md transition-colors cursor-pointer ${isCurrent ? 'bg-surfaceHighlight/30' : ''}`}
              onDoubleClick={() => onPlay(song.id)}
            >
              <div className="w-8 flex justify-center items-center text-textMuted group-hover:text-white">
                {isCurrent ? (
                  isCurrentPlaying ? (
                     <div className="flex space-x-[2px] items-end h-3 w-3">
                        <div className="w-[3px] bg-primary animate-[bounce_1s_infinite] h-full"></div>
                        <div className="w-[3px] bg-primary animate-[bounce_1.2s_infinite] h-2/3"></div>
                        <div className="w-[3px] bg-primary animate-[bounce_0.8s_infinite] h-full"></div>
                     </div>
                  ) : (
                    <span className="text-primary font-bold">{index + 1}</span>
                  )
                ) : (
                  <span className="group-hover:hidden">{index + 1}</span>
                )}
                <button
                  className={`hidden group-hover:flex items-center justify-center ${isCurrent ? 'hidden' : ''}`}
                  onClick={() => onPlay(song.id)}
                >
                  <Play className="w-4 h-4 fill-current" />
                </button>
                {isCurrent && !isCurrentPlaying && (
                   <button onClick={() => onPlay(song.id)}>
                     <Play className="w-4 h-4 fill-primary text-primary" />
                   </button>
                )}
                {isCurrent && isCurrentPlaying && (
                   <button onClick={onPause} className="hidden group-hover:block">
                     <Pause className="w-4 h-4 fill-primary text-primary" />
                   </button>
                )}
              </div>

              <div className="flex items-center space-x-3 overflow-hidden">
                <div className="h-10 w-10 flex-shrink-0 bg-gradient-to-br from-zinc-700 to-zinc-800 rounded-md flex items-center justify-center border border-white/5">
                     <Music className="w-5 h-5 text-zinc-500" />
                </div>
                <div className="overflow-hidden min-w-0">
                    <p className={`truncate font-medium ${isCurrent ? 'text-primary' : 'text-textMain'}`}>
                    {song.title}
                    </p>
                    <p className="truncate text-xs text-textMuted">{song.artist}</p>
                </div>
              </div>

              <div className="hidden md:block text-sm text-textMuted truncate">
                {new Date(song.dateAdded).toLocaleDateString()}
              </div>

              <div className="text-sm text-textMuted text-right pr-4 tabular-nums">
                {formatTime(song.duration)}
              </div>

              <div className="flex items-center justify-end space-x-2 relative">
                {/* Add to Playlist Dropdown */}
                <div className="relative">
                  <button 
                    className="p-1.5 rounded-full hover:bg-zinc-700 text-textMuted hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Add to Playlist"
                    onClick={(e) => handlePlaylistClick(e, song.id)}
                  >
                    <Plus className="w-4 h-4" />
                  </button>
                  
                  {activeMenuId === song.id && (
                    <div className="absolute right-0 top-8 w-48 bg-surfaceHighlight border border-zinc-700 rounded-md shadow-xl z-50 py-1">
                       <div className="px-3 py-2 text-xs font-semibold text-textMuted border-b border-zinc-700/50 mb-1">
                         Add to Playlist
                       </div>
                       {playlists.length === 0 && (
                          <div className="px-3 py-2 text-sm text-textMuted italic">No playlists</div>
                       )}
                       {playlists.map(pl => (
                         <button
                           key={pl.id}
                           className="w-full text-left px-3 py-2 text-sm hover:bg-primary/20 hover:text-primary transition-colors flex items-center space-x-2"
                           onClick={(e) => {
                              e.stopPropagation();
                              if (onAddToPlaylist) {
                                onAddToPlaylist(song.id, pl.id);
                                setActiveMenuId(null);
                              }
                           }}
                         >
                           <ListMusic className="w-3 h-3" />
                           <span className="truncate">{pl.name}</span>
                         </button>
                       ))}
                    </div>
                  )}
                </div>

                {onEdit && (
                   <button 
                     className="p-1.5 rounded-full hover:bg-zinc-700 text-textMuted hover:text-white opacity-0 group-hover:opacity-100 transition-opacity"
                     title="Edit Info"
                     onClick={(e) => { e.stopPropagation(); onEdit(song); }}
                   >
                     <Pencil className="w-4 h-4" />
                   </button>
                )}

                {onDelete && (
                  <button 
                    className="p-1.5 rounded-full hover:bg-red-500/20 text-textMuted hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                    title="Remove from library"
                    onClick={(e) => { e.stopPropagation(); onDelete(song.id); }}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                )}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};