import React from 'react';
import { Library, PlusSquare, ListMusic, Home, Upload, Github } from 'lucide-react';
import { Playlist, ViewState } from '../types';

interface SidebarProps {
  currentView: ViewState;
  selectedPlaylistId: string | null;
  playlists: Playlist[];
  onChangeView: (view: ViewState, playlistId?: string) => void;
  onCreatePlaylist: () => void;
  onUploadClick: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  selectedPlaylistId,
  playlists,
  onChangeView,
  onCreatePlaylist,
  onUploadClick
}) => {
  return (
    <div className="w-64 bg-black h-full flex flex-col border-r border-surfaceHighlight p-4 space-y-6">
      <div className="flex items-center space-x-2 px-2 mb-2">
        <div className="w-8 h-8 bg-gradient-to-br from-primary to-blue-600 rounded-lg flex items-center justify-center">
            <span className="font-bold text-white text-lg">C</span>
        </div>
        <span className="text-xl font-bold tracking-tight text-white">Cracowtune</span>
      </div>

      <div className="space-y-1">
        <button
          onClick={() => onChangeView('library')}
          className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md font-medium transition-colors ${
            currentView === 'library' ? 'bg-surfaceHighlight text-white' : 'text-textMuted hover:text-white hover:bg-surfaceHighlight/50'
          }`}
        >
          <Home className="w-5 h-5" />
          <span>Library</span>
        </button>
        <button
           onClick={onUploadClick}
           className="w-full flex items-center space-x-3 px-3 py-2 rounded-md font-medium text-textMuted hover:text-white hover:bg-surfaceHighlight/50 transition-colors"
        >
            <Upload className="w-5 h-5" />
            <span>Upload Songs</span>
        </button>
      </div>

      <div className="space-y-4 flex-1 overflow-y-auto">
        <div className="flex items-center justify-between px-3">
          <h2 className="text-xs font-semibold text-textMuted uppercase tracking-wider">Playlists</h2>
          <button 
            onClick={onCreatePlaylist}
            className="text-textMuted hover:text-white transition-colors"
            title="Create Playlist"
          >
            <PlusSquare className="w-4 h-4" />
          </button>
        </div>
        
        <div className="space-y-1">
          {playlists.map(playlist => (
            <button
              key={playlist.id}
              onClick={() => onChangeView('playlist', playlist.id)}
              className={`w-full flex items-center space-x-3 px-3 py-2 rounded-md text-sm transition-colors ${
                currentView === 'playlist' && selectedPlaylistId === playlist.id
                  ? 'bg-surfaceHighlight text-white' 
                  : 'text-textMuted hover:text-white hover:bg-surfaceHighlight/50'
              }`}
            >
              <ListMusic className="w-4 h-4" />
              <span className="truncate">{playlist.name}</span>
            </button>
          ))}
          {playlists.length === 0 && (
             <div className="px-3 text-xs text-textMuted italic">No playlists created.</div>
          )}
        </div>
      </div>
      
      <div className="pt-4 border-t border-surfaceHighlight px-2">
         <div className="bg-gradient-to-r from-zinc-800 to-zinc-900 rounded-lg p-4">
            <p className="text-xs text-textMuted">
                Your library is automatically saved to your device.
            </p>
         </div>
      </div>
    </div>
  );
};