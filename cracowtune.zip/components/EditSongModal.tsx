import React, { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Song } from '../types';
import { Button } from './Button';

interface EditSongModalProps {
  isOpen: boolean;
  song: Song | null;
  onClose: () => void;
  onSave: (id: string, title: string, artist: string) => void;
}

export const EditSongModal: React.FC<EditSongModalProps> = ({
  isOpen,
  song,
  onClose,
  onSave
}) => {
  const [title, setTitle] = useState('');
  const [artist, setArtist] = useState('');

  useEffect(() => {
    if (song) {
      setTitle(song.title);
      setArtist(song.artist);
    }
  }, [song]);

  if (!isOpen || !song) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSave(song.id, title, artist);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm p-4">
      <div className="bg-surface border border-surfaceHighlight rounded-lg shadow-xl w-full max-w-md animate-in fade-in zoom-in duration-200">
        <div className="flex items-center justify-between p-4 border-b border-surfaceHighlight">
          <h2 className="text-lg font-semibold text-white">Edit Details</h2>
          <button 
            onClick={onClose}
            className="text-textMuted hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          <div className="space-y-2">
            <label htmlFor="title" className="text-sm font-medium text-textMuted">Title</label>
            <input
              id="title"
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full bg-surfaceHighlight border border-zinc-700 rounded-md px-3 py-2 text-textMain focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="Song Title"
              required
            />
          </div>
          
          <div className="space-y-2">
            <label htmlFor="artist" className="text-sm font-medium text-textMuted">Artist</label>
            <input
              id="artist"
              type="text"
              value={artist}
              onChange={(e) => setArtist(e.target.value)}
              className="w-full bg-surfaceHighlight border border-zinc-700 rounded-md px-3 py-2 text-textMain focus:outline-none focus:ring-2 focus:ring-primary focus:border-transparent transition-all"
              placeholder="Artist Name"
            />
          </div>

          <div className="flex justify-end space-x-3 pt-2">
            <Button type="button" variant="ghost" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit" variant="primary">
              Save Changes
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
};