import React, { useRef, useEffect } from 'react';
import { Play, Pause, SkipBack, SkipForward, Volume2, VolumeX, Repeat, Shuffle, Mic2, Music } from 'lucide-react';
import { Song, PlayerState } from '../types';

interface PlayerProps {
  currentSong: Song | null;
  playerState: PlayerState;
  togglePlay: () => void;
  nextSong: () => void;
  prevSong: () => void;
  toggleShuffle: () => void;
  toggleRepeat: () => void;
  onTimeUpdate: (time: number) => void;
  onDurationChange: (duration: number) => void;
  onEnded: () => void;
  setVolume: (vol: number) => void;
}

export const Player: React.FC<PlayerProps> = ({
  currentSong,
  playerState,
  togglePlay,
  nextSong,
  prevSong,
  toggleShuffle,
  toggleRepeat,
  onTimeUpdate,
  onDurationChange,
  onEnded,
  setVolume
}) => {
  const audioRef = useRef<HTMLAudioElement>(null);
  const progressRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (currentSong && audioRef.current) {
        // Only load if the source changed to prevent reset on re-renders
        const currentSrc = audioRef.current.src;
        if (currentSrc !== currentSong.url) {
            audioRef.current.src = currentSong.url;
            audioRef.current.load();
            if (playerState.isPlaying) {
                audioRef.current.play().catch(e => console.error("Play error", e));
            }
        } else {
            // If same song, check play state
            if (playerState.isPlaying && audioRef.current.paused) {
                audioRef.current.play().catch(e => console.error("Play error", e));
            } else if (!playerState.isPlaying && !audioRef.current.paused) {
                audioRef.current.pause();
            }
        }
    } else if (!currentSong && audioRef.current) {
        audioRef.current.pause();
        audioRef.current.src = "";
    }
  }, [currentSong, playerState.isPlaying]);

  useEffect(() => {
      if (audioRef.current) {
          audioRef.current.volume = playerState.volume;
      }
  }, [playerState.volume]);

  useEffect(() => {
    // If repeat one is on and song ended, this is handled by onEnded prop logic usually
    // but the audio tag 'loop' attribute can be used for seamless looping
    if (audioRef.current) {
      audioRef.current.loop = playerState.repeatMode === 'one';
    }
  }, [playerState.repeatMode]);

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const time = Number(e.target.value);
    if (audioRef.current) {
      audioRef.current.currentTime = time;
    }
    onTimeUpdate(time);
  };

  const formatTime = (seconds: number) => {
    if (isNaN(seconds)) return "0:00";
    const mins = Math.floor(seconds / 60);
    const secs = Math.floor(seconds % 60);
    return `${mins}:${secs.toString().padStart(2, '0')}`;
  };

  const duration = audioRef.current?.duration || 0;

  return (
    <div className="h-24 bg-surface/95 border-t border-surfaceHighlight backdrop-blur-md flex flex-col justify-center px-4 fixed bottom-0 left-0 right-0 z-50">
      <audio
        ref={audioRef}
        onTimeUpdate={(e) => onTimeUpdate(e.currentTarget.currentTime)}
        onDurationChange={(e) => onDurationChange(e.currentTarget.duration)}
        onEnded={onEnded}
        onError={(e) => console.error("Audio error", e)}
      />
      
      <div className="flex items-center justify-between max-w-7xl mx-auto w-full h-full gap-4">
        {/* Song Info */}
        <div className="w-1/3 min-w-[180px] flex items-center space-x-4">
          {currentSong ? (
            <>
              <div className="h-14 w-14 bg-surfaceHighlight rounded-md flex items-center justify-center shadow-lg overflow-hidden relative group">
                <div className="absolute inset-0 bg-primary/20 flex items-center justify-center">
                    <Music className="w-6 h-6 text-primary" />
                </div>
              </div>
              <div className="overflow-hidden">
                <div className="font-semibold text-textMain truncate hover:underline cursor-default" title={currentSong.title}>
                  {currentSong.title}
                </div>
                <div className="text-xs text-textMuted truncate cursor-default" title={currentSong.artist}>
                  {currentSong.artist}
                </div>
              </div>
            </>
          ) : (
            <div className="text-textMuted text-sm italic">Select a song to play</div>
          )}
        </div>

        {/* Controls */}
        <div className="flex flex-col items-center w-1/3 max-w-xl">
          <div className="flex items-center space-x-6 mb-2">
            <button 
                onClick={toggleShuffle}
                className={`transition-colors ${playerState.isShuffle ? 'text-primary' : 'text-textMuted hover:text-white'}`}
                title="Shuffle"
            >
              <Shuffle className="w-4 h-4" />
            </button>
            <button onClick={prevSong} className="text-textMain hover:text-primary transition-colors">
              <SkipBack className="w-5 h-5 fill-current" />
            </button>
            <button 
              onClick={togglePlay} 
              className="h-10 w-10 bg-white rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-lg shadow-white/10"
              disabled={!currentSong}
            >
              {playerState.isPlaying ? (
                <Pause className="w-5 h-5 text-black fill-current" />
              ) : (
                <Play className="w-5 h-5 text-black fill-current ml-0.5" />
              )}
            </button>
            <button onClick={nextSong} className="text-textMain hover:text-primary transition-colors">
              <SkipForward className="w-5 h-5 fill-current" />
            </button>
            <button 
                onClick={toggleRepeat}
                className={`transition-colors relative ${playerState.repeatMode !== 'off' ? 'text-primary' : 'text-textMuted hover:text-white'}`}
                title="Repeat"
            >
              <Repeat className="w-4 h-4" />
              {playerState.repeatMode === 'one' && (
                  <span className="absolute -top-1 -right-2 text-[8px] font-bold">1</span>
              )}
            </button>
          </div>
          
          <div className="w-full flex items-center space-x-3 text-xs text-textMuted font-mono">
            <span>{formatTime(playerState.progress)}</span>
            <div className="relative flex-1 h-1 bg-surfaceHighlight rounded-full group cursor-pointer">
               <input
                ref={progressRef}
                type="range"
                min={0}
                max={duration || 100}
                value={playerState.progress}
                onChange={handleSeek}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
                disabled={!currentSong}
              />
              <div 
                className="absolute top-0 left-0 h-full bg-primary rounded-full"
                style={{ width: `${(playerState.progress / (duration || 1)) * 100}%` }}
              ></div>
              {/* Thumb visible on hover */}
              <div 
                className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                style={{ left: `${(playerState.progress / (duration || 1)) * 100}%`, transform: 'translate(-50%, -50%)' }}
              ></div>
            </div>
            <span>{formatTime(duration)}</span>
          </div>
        </div>

        {/* Volume */}
        <div className="w-1/3 flex justify-end items-center space-x-3 min-w-[150px]">
          <button 
            onClick={() => setVolume(playerState.volume === 0 ? 1 : 0)}
            className="text-textMuted hover:text-white transition-colors"
          >
            {playerState.volume === 0 ? <VolumeX className="w-5 h-5" /> : <Volume2 className="w-5 h-5" />}
          </button>
          <div className="w-24 relative h-1 bg-surfaceHighlight rounded-full group">
            <input
                type="range"
                min={0}
                max={1}
                step={0.01}
                value={playerState.volume}
                onChange={(e) => setVolume(Number(e.target.value))}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer z-10"
            />
            <div 
                className="absolute top-0 left-0 h-full bg-textMuted group-hover:bg-primary rounded-full"
                style={{ width: `${playerState.volume * 100}%` }}
            ></div>
             <div 
                className="absolute top-1/2 -translate-y-1/2 w-3 h-3 bg-white rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none"
                style={{ left: `${playerState.volume * 100}%`, transform: 'translate(-50%, -50%)' }}
              ></div>
          </div>
        </div>
      </div>
    </div>
  );
};