export interface Song {
  id: string;
  title: string;
  artist: string;
  album?: string;
  duration: number; // in seconds
  file: File;
  url: string; // Blob URL
  dateAdded: number;
}

export interface Playlist {
  id: string;
  name: string;
  description?: string;
  songIds: string[];
  createdAt: number;
}

export type ViewState = 'library' | 'favorites' | 'playlist';

export interface PlayerState {
  currentSongId: string | null;
  isPlaying: boolean;
  volume: number;
  progress: number; // Current time in seconds
  isShuffle: boolean;
  repeatMode: 'off' | 'all' | 'one';
}

export interface QueueState {
  originalQueue: string[]; // Ordered list of IDs based on current view
  shuffledQueue: string[]; // Shuffled version
  currentIndex: number;
}